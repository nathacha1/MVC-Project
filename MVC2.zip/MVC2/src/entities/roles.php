<?php
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;


/**
 * @ORM\Entity @ORM\Table(name="Roles")
 */



class roles 
{
    /** @ORM\Id @ORM\Column(type="integer") @ORM\GeneratedValue */
    private $id;
        /**@ORM\Column(type="String") **/
    private $nom;
     /**
     * Many roles have Many Users.
     * @ORM\ManyToMany(targetEntity="Users", mappedBy="roles")
     */
    private $users;



    public function __construct()
    {
        $this->user = new ArrayCollection();

    }

    public function getId()
    {
        return $this->id;
    }
    public function setId($id)
    {
        return $this->id = $id;
    }
    

    public function getNom()
    {
        return $this->nom;
    }
    public function setNom($nom)
    {
        return $this->nom = $nom;
    }

    public function getUsers()
    {
        return $this->users;
    }
    public function setUsers($users)
    {
        return $this->users = $users;
    }

    
}


?>