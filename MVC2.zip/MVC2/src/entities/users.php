<?php
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;


/**
 * @ORM\Entity @ORM\Table(name="Users")
 */


class Users
{
     /** @ORM\Id @ORM\Column(type="integer") @ORM\GeneratedValue **/
    private $id;
    /**@ORM\Column(type="String") **/
    private $nom;
    /**@ORM\Column(type="String") **/
    private $prenom;
    /**@ORM\Column(type="String") **/
    private $email;
    /**@ORM\Column(type="String") **/
    private $password;
    /**
     * One user has many lieux. This is the inverse side.
     * @ORM\OneToMany(targetEntity="Lieu", mappedBy="user")
     */
    private $lieux;
     /**
     * Many Users have Many roles.
     * @ORM\ManyToMany(targetEntity="roles", inversedBy="users")
     * @ORM\JoinTable(name="users_roles")
     */
    private $roles;



    public function __construct()
    {
        $this->lieux = new ArrayCollection();
        $this->roles = new ArrayCollection();


    }

    public function getId()
    {
        return $this->id;
    }
    public function setId($id)
    {
        return $this->id = $id;
    }
    

    public function getNom()
    {
        return $this->nom;
    }
    public function setNom($nom)
    {
        return $this->nom = $nom;
    }

    public function getPrenom()
    {
        return $this->prenom;
    }
    public function setPrenom($prenom)
    {
        return $this->prenom = $prenom;
    }

    public function getEmail()
    {
        return $this->email;
    }
    public function setEmail($email)
    {
        return $this->email = $email;
    }

    public function getPassword()
    {
        return $this->password;
    }
    public function setPassword($password)
    {
        return $this->password = $password;
    }

    public function getLieux()
    {
        return $this->lieux;
    }
    public function setLieux($lieux)
    {
        return $this->lieux = $lieux;
    }

    public function getRoles()
    {
        return $this->roles;
    }
    public function setRoles($roles)
    {
        return $this->roles = $roles;
    }
}


?>