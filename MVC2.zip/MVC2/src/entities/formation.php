<?php
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity @ORM\Table(name="formation")
 **/
class Formation 
{
    /** @ORM\Id @ORM\Column(type="integer") @ORM\GeneratedValue **/
    private $id;
    /**@ORM\Column(type="String") **/
    private $nom;
    /**@ORM\Column(type="String") **/
    private $date;
    /**@ORM\Column(type="Integer") **/
    private $duree;
     /**
     * Many formations have one lieu. This is the owning side.
     * @ORM\ManyToOne(targetEntity="Lieu", inversedBy="formations")
     * @ORM\JoinColumn(name="lieu_id", referencedColumnName="id")
     */

    /**@ORM\Column(type="String") **/
    private $lieu;


    public function __construct()
    {

    }

    public function getId()
    {
        return $this->id;
    }
    public function setId($id)
    {
        return $this->id = $id;
    }
    

    public function getNom()
    {
        return $this->nom;
    }
    public function setNom($nom)
    {
        return $this->nom = $nom;
    }

    public function getDate()
    {
        return $this->date;
    }
    public function setDate($date)
    {
        return $this->date = $date;
    }

    public function getDuree()
    {
        return $this->duree;
    }
    public function setDuree($duree)
    {
        return $this->duree = $duree;
    }

    public function getLieu()
    {
        return $this->lieu;
    }
    public function setLieu($lieu)
    {
        return $this->lieu = $lieu;
    }
}


?>