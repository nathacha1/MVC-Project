<?php
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;


/**
 * @ORM\Entity @ORM\Table(name="Lieu")
 **/



class Lieu
{
     /** @ORM\Id @ORM\Column(type="integer") @ORM\GeneratedValue **/

    private $id;
    /**@ORM\Column(type="String") **/
    private $nom;
    /**@ORM\Column(type="decimal") **/
    private $latitude;
     /**
     * One lieu has many formation. This is the inverse side.
     * @ORM\OneToMany(targetEntity="formation", mappedBy="lieu")
     */
    /**@ORM\Column(type="Decimal") **/
    private $longitude;
    private $formation;
    /**
     * Many lieu have one user. This is the owning side.
     * @ORM\ManyToOne(targetEntity="users", inversedBy="lieux")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    private $users;




    public function __construct()
    {
        $this->features = new ArrayCollection();

    }

    public function getId()
    {
        return $this->id;
    }
    public function setId($id)
    {
        return $this->id = $id;
    }
    

    public function getNom()
    {
        return $this->nom;
    }
    public function setNom($nom)
    {
        return $this->nom = $nom;
    }

    public function getLatitude()
    {
        return $this->latitude;
    }
    public function setLatitude($latitude)
    {
        return $this->latitude = $latitude;
    }

    public function getLongitude()
    {
        return $this->longitude;
    }
    public function setLongitude($longitude)
    {
        return $this->longitude = $longitude;
    }

    public function getFormation()
    {
        return $this->formation;
    }
    public function setFormation($Formation)
    {
        return $this->formation = $formation;
    }


    public function getUsers()
    {
        return $this->users;
    }
    public function setUsers($users)
    {
        return $this->users = $users;
    }
}


?>