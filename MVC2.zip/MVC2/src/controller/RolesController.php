<?php
// namespace src\controller;
use libs\system\controller;
use src\model\rolesDB;

class RolesController extends controller
{
    public function add()
    {
        return $this->view->load("roles/add");

    }
    public function getAll()
    {
        $roles_dao= new rolesDB();
        $roles = $roles_dao->findAll();
        // $roles = array("ROLE_USER", "ROLE_ADMIN");
        return $this->view->load("roles/getAll", $roles);
    }
    public function delete($id)
    {
        echo $id;
    
        // $roles = array("ROLE_USER", "ROLE_ADMIN");
        // return $this->view->load("roles/getAll",$roles);
    }
}

?>  