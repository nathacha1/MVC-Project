<?php
namespace src\model;
use libs\system\model;

class rolesDB extends model
{
    public function findAll()
    {

         return $this->entityManager
                     ->createQuery("SELECT r FROM roles r")
                     ->getResult();
            // array("ROLE_COMPTA","ROLE_FINANCE");
    }
}
?>