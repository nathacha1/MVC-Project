<?php
require_once "config/autoload.php";
// use src\controller\RolesController;
// $roles_dao = new RolesController(); 
// // $rolesdao->add();
// $roles_dao->getAll();

$mvc =new libs\system\boostrap();

?>